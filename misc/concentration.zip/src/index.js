import React from 'react';
import { render } from 'react-dom';
const rootUrl = 'https://raw.githubusercontent.com/C4Q/AC_4_Web/master/units/react/exercises/objects_and_arrays/cards/'
const cardNames = [ 'apple', 'camera', 'clover', 'heart',
                       'key', 'paw', 'smiley', 'snowflake',
                       'apple', 'camera', 'clover', 'heart',
                       'key', 'paw', 'smiley', 'snowflake',
                     ]

function shuffleArr(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
  return array
}
  
class Card extends React.Component {
  constructor(props){
    super(props);
    this.name = props.name
    
  }
  
  handleClick = e => {
    this.props.handler(e)  
  }
  
  render(){
    const { name, id, flipped } = this.props
    let src;
    
    //Set src based on flipped flag
    if (flipped) {
      src =  rootUrl + name + '.png' 
    } else {
      src = rootUrl + 'back.png' 
    }
    
    
    return(
     <img
       name={name}
       id={id}
       src={src}
       alt={ name + ' picture'}
       onClick={this.handleClick}
     />
    )
    
  } 
}


class Board extends React.Component {
  constructor(){
    super();
    this.cards = shuffleArr(cardNames) 
  
    this.state = {
      clickedCards: [], //clickedCards: ['key', 'heart'],
      ids: [],     //indexes: [4, 11],
      matches: []
    }
  }
 
  attemptFlipCard = (e) => {
    const { clickedCards, ids, matches } = this.state
    const card = e.target.name
    const id = e.target.id
    
    
    // Check if we have clicked two cards already
    if (clickedCards.length == 2) {
      //Reset clicked cards putting only latest click
      let newClickedCards = [card]
      let newIds = [id]
      this.setState({
        clickedCards: newClickedCards,
        ids: newIds
      })
      
    } else {
      
      let newClickedCards = [...clickedCards, card]
      let newIds = [...ids, id]
      this.setState({
        clickedCards: newClickedCards,
        ids: newIds,
      })
      
      //Check for match where we have same card at two different places
      if(newClickedCards[0] === newClickedCards[1] && newIds[0] !== newIds[1]) {
        const newMatches = [...matches, card]
        this.setState({
          matches: newMatches
        })
      }
    }
  }
  
  render(){
    console.log(this.state)
    const { clickedCards, ids, matches } = this.state
    return (
      <div>
        {this.cards.map( (card, index) => (
          <Card
            name={card}
            id={index} 
            flipped={ matches.includes(card) || (clickedCards.includes(card) && ids.includes(index.toString())) }
            handler={this.attemptFlipCard}
          />))}
      </div>
    )
  }
  
};

render(<Board />, document.getElementById('root'));
